<?php
require_once 'dbconnect.php';

$conn = connectDB();
if (isset($_POST['id']) && 
    isset($_POST['username'])) {
        $id = $_POST['id'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role = $_POST['role'];

        $sql="SELECT username FROM account WHERE username='$username' LIMIT 1";
        $result = mysqli_query($conn, $sql);
        $row=mysqli_fetch_assoc($result);
        if ($row) {
            if($row['username'] === $username){
                echo "username already exists <a href='javascript: history.go(-1)'>Back to login page</a>";
            }
            
        } else {
            $sql = "INSERT into account(AccountID, username, password, user_type) values('$id', '$username', '$password', '$role')";
            if (mysqli_query($conn, $sql)) {
                echo "New record created successfully <a href='javascript: history.go(-1)'>Back to login page</a>";
            }
        }
        
    }

mysqli_close($conn);


?>