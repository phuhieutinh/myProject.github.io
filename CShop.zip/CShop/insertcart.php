<?php
require_once 'dbconnect.php';

$conn = connectDB();

if (isset($_GET['id'])) {
    
    $id = $_GET['id'];
    
    $sql = "SELECT * FROM cart where ProductID = $id LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $row=mysqli_fetch_assoc($result);
    if ($row) {
        if($row['ProductID'] === $id){
            echo "username already exists <a href='javascript: history.go(-1)'>Back to login page</a>";
        }
    }
        
 else {
    $sql = "INSERT into cart(CartID, ProductID, quantity) values('int', '$id', 'int')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully <a href='javascript: history.go(-1)'>Back to login page</a>";
    }
}
}
?>